<?php

return array (
  'host' => '127.0.0.1',
  'port' => 3306,
  'name' => 'smartreport',
  'user' => 'smartreport',
  'pass' => '9e3f35dcf5b6c636c657',
  'charset' => 'utf8mb4',
);
