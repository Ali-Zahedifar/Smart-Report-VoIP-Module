<?php

return array (
  'cdr' => 
  array (
    'host' => 'localhost',
    'port' => 3306,
    'name' => 'asteriskcdrdb',
    'user' => 'root',
    'pass' => '',
    'charset' => 'utf8mb4',
  ),
  'asterisk' => 
  array (
    'host' => 'localhost',
    'port' => 3306,
    'name' => 'asterisk',
    'user' => 'asteriskuser',
    'pass' => '',
    'charset' => 'utf8mb4',
  ),
  'ami' => 
  array (
    'enabled' => false,
    'host' => '127.0.0.1',
    'port' => 5038,
    'username' => 'admin',
    'password' => '',
  ),
  'monitor_dir' => '/var/spool/asterisk/monitor',
);
