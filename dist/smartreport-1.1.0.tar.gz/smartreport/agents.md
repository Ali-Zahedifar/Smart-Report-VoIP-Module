# Agent / Extension Handling in Smart-Report

This document describes how agents (extensions) are identified, tracked, and reported in Smart-Report. It is intended for developers and system integrators.

---

## How Agents Are Identified

### Primary Source: Asterisk Reference Database
Smart-Report queries the **Issabel/Asterisk configuration database** (`asterisk` DB) via `ReferenceRepository`:

| Table | Column | Purpose |
|-------|--------|---------|
| `users` | `extension` | User extensions (primary) |
| `devices` | `id` | SIP/IAX device identifiers |
| `queues_config` | `extension` | Queue member extensions |
| `ringgroups` | `grpnum` | Ring group numbers |
| `incoming` | `extension` | DID/inbound route targets |
| `trunks` | `name`, `channelid` | Trunk identifiers |

The reference DB is queried on first load and cached for 1 hour (`refdata_v2` in `data/cache/`).

### Fallback: CDR Self-Learning
When the Asterisk DB is unreachable or empty, `ReferenceRepository::learnFromCdr()` learns from the CDR table (`asteriskcdrdb.cdr`):

1. **Extensions**: Numeric SIP/PJSIP peers originating in internal contexts
   - Scans `cdr.channel` for `SIP/XXX-` or `PJSIP/XXX-` where `dcontext` NOT in trunk contexts
   - Excludes peers that match known trunk idents
   - Stores in `$this->internalExtensions`

2. **Trunks**: Channel peers seen on inbound/outbound contexts
   - Scans `cdr.channel` where `dcontext IN ('ext-trunk','from-did-direct','from-did','ext-queues','from-pstn')`
   - Extracts `tech/peer` from `SIP/peer-...` or `PJSIP/peer-...`
   - Stores in `$this->trunkIdents`

### Queue Agent Detection (CDR Leg Analysis)
Queue calls create multiple CDR rows per `linkedid`:
- **Origin leg**: `ext-queues` context, trunk channel (e.g., `SIP/1872-...`), `dst` = queue number (2000, 2200, etc.)
- **Agent legs**: `Local/XXX@from-queue-...;2` or `Local/XXX@from-internal;2` in `from-internal` context
- The `;2` suffix indicates the agent side of the Local channel pair
- Extension `XXX` is extracted and tracked as the answering agent

---

## Missed Calls & Agents

### Missed Call Definition
A call is **missed** when ALL conditions are met:
1. **Direction = inbound** (`direction === 'in'`)
2. **Rang human endpoints** (had opportunity to be answered):
   - Queue calls with agent legs (`Local/XXX@from-queue...;2`)
   - Ring groups (≥2 simultaneous `Local/...;2` legs in `from-internal`)
   - Direct DID/extension (`from-did-direct`, `from-pstn`, `ext-did` → `Local/` or `SIP/` extension)
   - IVR → Extension (`ivr-*` → extension leg)
   - Queue overflow to external (`ext-queues` leg with external `dst`)
3. **No human answered** (`humanAnswered = false`):
   - No `ANSWERED` disposition on non-automation `Dial` legs
   - Automation apps excluded: `VOICEMAIL`, `PLAYBACK`, `ANNOUNCEMENT`, `IVR`, `WAIT`, `BACKGROUND`, `QUEUE`, `CONGESTION`, `BUSY`, `HANGUP`, etc.
4. **Final disposition** in: `NO ANSWER`, `BUSY`, `FAILED`, `CONGESTION`, `CANCEL`, `VOICEMAIL`

### Voicemail Handling
- Calls answered by voicemail (`VOICEMAIL` or `VOICEMAILMAIN` app with `ANSWERED` disposition) are **counted as missed**
- Marked with `missedReason = 'voicemail'`
- Displayed as "Handled by Voicemail" in UI (not a true miss, but tracked for reporting)

---

## Queue Report - Agent Metrics

The **Queue Report** module (`/queue-report`) computes per-agent statistics from CDR leg analysis:

| Metric | Source |
|--------|--------|
| Calls Answered | `Dial` legs with `ANSWERED` disposition where `channel = Local/XXX@...;2` |
| Calls Missed | `Dial` legs with non-`ANSWERED` disposition on agent legs |
| Avg Talk Time | Sum of `billsec` on answered agent `Dial` legs / answered count |
| Queue Wait Time | `QUEUE` app leg `billsec` (time caller spent in queue before agent) |

### Agent Ranking
- Agents ranked by **answered calls descending**
- Top 20 displayed in Reports module "Agent Performance" chart
- Detail view shows all agents for a specific queue

---

## Configuration

### Explicit Routing Lists (config/external.php)
```php
'routing' => [
    'extensions' => ['100', '101', '102', '200', '201', ...],  // explicit extension list
    'queues' => ['2000', '2200', '3000'],                     // queue numbers
    'ringgroups' => ['600', '601'],                           // ring group numbers
    'dids' => ['5551234', '5555678'],                         // DID numbers
    'trunks' => ['SIP/trunk1', 'PJSIP/trunk2'],               // trunk channel prefixes
    'channels' => [
        'trunk' => ['SIP/', 'PJSIP/', 'DAHDI/', 'IAX2/']      // trunk channel prefixes
    ],
    'contexts' => [
        'in' => ['from-pstn', 'from-did', 'from-trunk', 'from-did-direct', 'ext-did', 'ivr-*', 'ext-queues'],
        'out' => ['outbound-allroutes', 'out-', 'ext-trunk']
    ]
]
```

### Cache Behavior
- Reference data cached as `refdata_v2` for 3600 seconds in `data/cache/`
- Force refresh: delete `data/cache/*.php` or wait for TTL expiry
- Cache key changed from `refdata_v1` → `refdata_v2` to invalidate old data

---

## Known Limitations

1. **Asterisk DB required for full accuracy** - CDR learning is heuristic and may miss extensions that never originate calls
2. **Ring group detection is heuristic** - Detects ≥2 simultaneous `Local/;2` legs in `from-internal` with same `linkedid` and `calldate`; may false-positive on parallel dials
3. **External overflow** - Queue calls that overflow to external numbers (e.g., mobile) are tracked as queue missed if no agent answered; the external leg is not analyzed for answer
4. **Local channel optimization** - Asterisk may optimize away Local channels; Smart-Report relies on `;2` suffix which may not appear if optimization occurs
5. **No real-time AMI integration** - Agent status (logged in/ready/on call) not available; only historical CDR analysis

---

## Extending Agent Detection

To add custom agent detection logic, modify `ReferenceRepository::learnFromCdr()` or add entries to `config/external.php → routing`. The `FeatureRegistry` will pick up new features on next `sync()` (triggered by installer or Settings → Modules save).