<?php
return array (
  'exp' => 1789806968,
  'data' => 
  array (
    0 => 'uniqueid',
    1 => 'calldate',
    2 => 'clid',
    3 => 'src',
    4 => 'dst',
    5 => 'duration',
    6 => 'billsec',
    7 => 'disposition',
    8 => 'recordingfile',
    9 => 'dcontext',
    10 => 'accountcode',
  ),
);
