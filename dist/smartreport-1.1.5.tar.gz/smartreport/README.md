# Smart-Report

Smart-Report is a standalone web module for **Issabel 4 & 5** PBXs that provides detailed, useful reports and tools for **callcenters**. It reads call data from the PBX (`asteriskcdrdb`), keeps its own module database on the server, and exposes a clean multilingual panel for users, admins, and the module owner.

**Current version (1.1.4)** adds call-center reporting on top of the 1.0 Foundation: a call-centric Calls page, direction filtering with automatic Asterisk-DB reference data, a **Missed inbound calls report**, **Graphical Reports** (6 chart types with PNG/PDF export), **Queue Report** (per-queue + agent metrics), and summary/full CSV exports. The 1.1.3 release added an **Extension Report** (per-extension productivity with charts and CSV), an **Employee Report** with dial-in clock codes (8810–8899) for work-session tracking, and a **Live Report** fed by the Asterisk Manager Interface (active calls, queue state, optional listen/whisper/barge for admins, root-gated). **1.1.4** fixes two fatals that fire only on a clean deploy (layout + Live view), treats 44-byte header-only WAV stubs as "No recording", and makes the installer enforce the post-deploy `systemctl restart httpd` + `grep app-version` verification. The 1.1.2 patch repaired the graphical-reports data endpoint, fixed internal-call classification (trunk peers / external numbers excluded, Persian digits normalized), shows recording buttons only for recordings that exist, and makes the expert call-legs expander opt-in.

## Features

- **All Calls** — call-centric CDR browsing (grouped by `linkedid`): direction filter, expandable legs, date/source/destination/status filters, pagination, and **summary + full CSV export**. The legs expander works on Calls, Missed and Internal lists (one shared, id-based handler safe for linkedids containing dots).
- **Call recordings** — inline player with **seek support** or download, served through an authenticated endpoint with HTTP `Range` support
- **Dashboard** — today's summary (total / answered / missed / average talk time), **direction tabs** (all / incoming / outgoing / internal / missed), a **Missed inbound calls** list with reason buckets (voicemail / no-answer / busy / cancelled / failed), and recent calls; direction/internal detection uses the Asterisk reference DB with a config fallback
- **Graphical Reports** — 6 chart types: calls by direction, calls by hour, missed calls trend (30 days), talk time distribution, queue performance, agent performance; client-side **PNG/PDF export** (Chart.js + jsPDF, works offline); root can **enable/disable individual charts** (persisted, applied without reload); click a queue bar to **drill into its detail view**
- **Queue Report** — per-queue metrics (offered, answered, missed, abandoned, abandonment rate, avg wait/talk, service level), per-agent stats (answered, missed, avg talk), detail view, CSV export
- **Recording playback** — recordings open in an **in-page modal player** from every list (Missed/Internal/Calls) with a download button; calls with a missing recording file show a clear "no recording" state instead of an empty player
- **Roles & users** — `root` (module owner), `admin`, `viewer`; user management with activation and password change
- **Modular feature registry** — each feature is self-contained and can be **enabled/disabled and rebranded** by the root user only (hidden from the customer)
- **i18n** — English and Persian (Farsi) with automatic RTL layout
- **Own database** — `smartreport` MariaDB database created by the installer; read-only connections to `asteriskcdrdb` (and `asterisk`, prepared for future reports)
- **Security baseline** — hashed passwords, login throttling, CSRF protection, prepared statements, blocked access to private folders

## Requirements

| Item | Requirement |
| --- | --- |
| OS | Issabel 4 or Issabel 5 (CentOS 7 / Rocky etc.) |
| PHP | 7.4 or newer (PDO MySQL, JSON, Session, OpenSSL) |
| Database | MariaDB/MySQL on the PBX server |
| Web server | Apache with `mod_rewrite` (nginx support documented) |
| Asterisk | CDR + `asteriskcdrdb` populated; recordings under `/var/spool/asterisk/monitor` (configurable) |
| Optional | `ffmpeg` (future transcoding), `mbstring` |

No composer dependencies. Everything needed is shipped in the repo.

## Quick start

```bash
# on the Issabel server (as root)
cp -r smartreport /var/www/html/smartreport
cd /var/www/html/smartreport
php install/installer.php
```

Open `http://YOUR-SERVER/smartreport/` and log in.

- Full details: [INSTALL.md](INSTALL.md)
- Removing it: [UNINSTALL.md](UNINSTALL.md)

## Roles

| Role | Capabilities |
| --- | --- |
| `root` | Everything: system check, user management, **module options** (enable/disable features, branding). Renameable; never granted to the customer. |
| `admin` | All data and settings except module options. |
| `viewer` | Browse data (calls, recordings, reports) and change own password. |

## How it works

- The installer creates the `smartreport` database, a dedicated DB user, the schema, the feature registry, and the `root`/`admin` users.
- `config/database.php` holds the module's own DB credentials; `config/external.php` holds read-only credentials for `asteriskcdrdb` / `asterisk`, the AMI settings placeholder, and the recording directory. Both are generated by the installer (not committed).
- Requests are routed by the front controller (`index.php`) through a lightweight router. En-abled features mount their routes and menu entries automatically.

### Directory map

```
smartreport/
├── index.php               Front controller
├── .htaccess               Rewrites + blocks config/data/storage/app/cron/install from web
├── assets/                 css + js (no build step)
├── config/
│   ├── app.php             App constants
│   ├── database.php        [generated] module DB credentials
│   ├── external.php        [generated] cdr/asterisk/AMI/monitor config
│   └── languages/          en.php, fa.php
├── install/
│   ├── installer.php       CLI installer
│   ├── uninstaller.php     CLI uninstaller
│   ├── preflight (see INSTALL)          php -l checks
│   ├── schema.sql, seed.sql
├── app/
│   ├── core/               Router, Database, Auth, Acl, Csrf, Lang, View, Config,
│   │                       FeatureRegistry, Controller, Response, helpers, routes
│   ├── controllers/        Auth + locale switch
│   ├── services/           Export (CSV), Cache, Audit
│   ├── features/           dashboard/, calls/, settings/  (see below)
│   └── templates/          layout, partials, auth, errors
├── data/cache, data/logs   Runtime writable (blocked from web)
├── storage/exports          Queued exports (blocked from web)
└── cron/                    Future scheduled-report scripts (CLI only)
```

## Adding a feature (modular design)

Each feature lives in `app/features/<id>/` and ships a `manifest.php`:

```php
<?php
return [
    'id' => 'queue_reports',
    'name' => 'Queue Reports',
    'version' => '1.0.0',
    'description' => 'Callcenter queue performance reports',
    'menu' => ['label' => 'queue_reports', 'icon' => 'phone', 'route' => '/reports/queue', 'order' => 30],
    'routes' => [
        'GET /reports/queue' => ['SmartReport\Features\QueueReports\Controllers\QueueReportsController@index', ['root', 'admin', 'viewer']],
    ],
    'roles' => ['root', 'admin', 'viewer'],
    'requires_ami' => false,
    'always_enabled' => false,
    // optional: 'depends' => ['calls'],
];
```

- The router mounts routes only for **enabled** features; disabled features vanish from the menu and return 404.
- `always_enabled => true` locks a feature so it cannot be disabled.
- Add a translation entry for `nav.<label>` in `config/languages/*.php`.
- Run `php install/installer.php` again (or the module-options save) so the registry syncs the new feature.

## Security notes

- Change the generated `root`/`admin` passwords immediately after install.
- The module should be served over HTTPS; the app honors secure-cookie flags when present.
- Keep `config/database.php` and `config/external.php` readable only by the web server / root (`0600` recommended, installer sets `0640`).
- `.htaccess` blocks web access to `config/`, `data/`, `storage/`, `app/`, `cron/`, and `install/`. For nginx, see INSTALL.md.

## Roadmap

- Data engine (incremental CDR/queue_log pull, rollups, cache) — foundation for fast reporting on large call volumes
- Queue & agent reports (volume, SLA, abandoned, per-agent/per-queue, hourly trends) with charts
- XLSX export, saved/scheduled reports with email delivery
- Live callcenter view via AMI (agent/queue status, wallboard)
- Supervisor tools (monitor/barge), IVR and missed-call reports, per-customer branding

## License

GPL-3.0. See [LICENSE](LICENSE).